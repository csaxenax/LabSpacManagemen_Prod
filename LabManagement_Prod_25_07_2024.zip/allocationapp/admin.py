from django.contrib import admin
from .models import AllocationDetailsModel,LabModel,ProgramsModel,BenchesModel
# Register your models here.
